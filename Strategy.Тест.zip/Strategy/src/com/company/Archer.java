package com.company;

public class Archer {
  private  int Health  = 8;
   private int Attack = 4;
   private int Armour = 0;

    public int getHealth() {
        return Health;
    }

    public void setHealth(int health) {
        this.Health = health;
    }

    public int getAttack() {
        return Attack;
    }

    public void setAttack(int attack) {
        this.Attack = attack;
    }
    public int getArmour() {
        return Armour;
    }
    public void setArmour(int armour) {
        this.Armour = armour;
    }
    public void attack(Spearman enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }
    public void attack(Horseman enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }
    public void attack(Archer enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }

    public void piercingShot(Spearman enemy){
        enemy.setHealth(enemy.getHealth()- this.Attack);
    }
    public void piercingShot(Horseman enemy){
        enemy.setHealth(enemy.getHealth()- this.Attack);
    }
    public void piercingShot(Archer enemy){
        enemy.setHealth(enemy.getHealth()- this.Attack);
    }

    public boolean isAlive() {
        if (Health > 10) {
            return  true;
        } else {
            System.out.println(Armour);
            return false;
        }
    }
}
