package com.company;

public interface Random {
    int nextInt(int i);
}
