package com.company;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;

public class UserTest {
    private int value;

    public UserTest() {
    }

    public void add(int Attack, String name, ArrayList<UserTest> ignoredUserTests) {
        value = Attack;
    }
    public int get() {
        return value;
    }
    @org.junit.Test
    public void testAdd() {
        ArrayList<UserTest> userTests = new ArrayList<>();
        UserTest userTest = new UserTest();
        userTest.add(4, "Archer", userTests);
        assertEquals(1, userTest.get());
    }
    public void add(int i, String name) {
    }
    @org.junit.Test
    public void testRed() {
        ArrayList<UserTest> userTests = new ArrayList<>();
        UserTest userTest = new UserTest();
        userTest.add(5, "Archer");
        userTest.Red(2, "Archer1");
        assertEquals("Archer1", userTest.get());
    }
    public void Red(int i, String name) {
    }
    private Object get(int i) {
        return null;
    }
    @org.junit.Test
    public void testDel() {
        ArrayList<UserTest> userTests = new ArrayList<>();
        UserTest userTest = new UserTest();
        userTest.add(2, "Archer3",userTests);
        userTest.Del(3, "Archer3", userTests);
        assertEquals(0, userTest.size());
    }
    public void Del(int i, String name, ArrayList<UserTest> ignoredUserTests) {
    }
    private int size() {
        return 0;
    }
}
