package com.company;

public class Spearman {
    int Health = 14;
    int Attack = 2;
    int Armour = 2;

    public int getHealth() {
        return Health;
    }

    public void setHealth(int health) {
        this.Health = health;
    }

    public int getAttack() {
        return Attack;
    }

    public void setAttack(int attack) {
        this.Attack = attack;
    }

    public int getArmour(){
        return Armour;
    }

    public void setArmour(int armour) {
        this.Armour = armour;
    }

    public void attack(Spearman enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }
    public void attack(Horseman enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }
    public void attack(Archer enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }

    public void fortify (){
        this.Armour+=2;
    }

    public boolean isAlive() {
        if (isAlive) {
            return "Alive";
        } else {
            System.out.println(Armour);
            return "Dead";
        }
    }
}
