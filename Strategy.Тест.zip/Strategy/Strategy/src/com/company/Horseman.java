package com.company;

public class Horseman {
    int Health = 20;
    int Attack = 5;
    int Armour = 1;

    public int getHealth() {
        return Health;
    }
    public void setHealth(int health) {
        this.Health = health;
    }

    public int getAttack() {
        return Attack;
    }

    public void setAttack(int attack) {
        this.Attack = attack;
    }


    public int getArmour(){
        return  Armour;
    }

    public void setArmour(int armour) {
        this.Armour = armour;
    }



    public void attack(Spearman enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }
    public void attack(Horseman enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }
    public void attack(Archer enemy){
        enemy.setHealth(enemy.getHealth()- (this.Attack-enemy.getArmour() ));
    }

    public void charge(Spearman enemy){
        enemy.setHealth(enemy.getHealth()-this.Attack*2);
    }
    public void charge(Horseman enemy){
        enemy.setHealth(enemy.getHealth()-this.Attack*2);
    }
    public void charge(Archer enemy){
        enemy.setHealth(enemy.getHealth()-this.Attack*2);
    }
}
