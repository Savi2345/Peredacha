package com.company;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random(System.currentTimeMillis());

        Spearman spearman = new Spearman();
        Archer archer1 = new Archer();
        printHP(spearman, archer1);

        while (spearman.isAlive() && archer1.isAlive()) {
            if (getChance(rnd) == 30)
                spearman.fortify();
            spearman.attack(archer1);

            if (getChance(rnd) == 20)
                archer1.piercingShot(spearman);
            else
                archer1.attack(spearman);
            printHP(spearman, archer1);
        }
        System.out.print("\nWinner is ");
        System.out.println(archer1.isAlive() ? "Archer1" : "Spearman");
    }
    private static void printHP(Spearman one, Archer two){
        System.out.printf("spearman: %-3d hp archer: %-3d hp\n",
                one.getHealth(), two.getHealth());
    }
        private static int getChance(Random rnd) {
            int a = rnd.nextInt(10);
            int b = rnd.nextInt(10);
            return ((a < 1)? 10 : a) + ((b < 1)? 10 : b);
        }
}
